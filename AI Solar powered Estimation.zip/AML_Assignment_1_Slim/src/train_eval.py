"""Task 4: NumPy fitting, train-only scaling/rate selection, held-out evaluation.

Both feature sets use the same complete-case timestamps. No estimator, scaler,
or metric libraries are used. Public-weather conclusions remain provisional.
"""
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from regression import cost, fit_batch_gd, fit_normal, fit_sgd, rmse

ROOT = Path(__file__).resolve().parent.parent
DATA, RESULTS = ROOT / "data", ROOT / "results"
TRAIN_START, TRAIN_END = pd.Timestamp("2020-05-15"), pd.Timestamp("2020-06-10")
TEST_START, TEST_END = pd.Timestamp("2020-06-11"), pd.Timestamp("2020-06-17")
FEATURES_A = ["irradiation", "module_temp", "ambient_temp", "sin_hour", "cos_hour"]
FEATURES_B = ["sw_radiation", "temp_2m", "cloud_cover", "sin_hour", "cos_hour"]
FINAL_SGD_EPOCHS = 1000  # fixed training budget, never chosen from test scores
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})


def add_hour_features(frame):
    frame = frame.copy()
    angle = 2 * np.pi * frame["datetime"].dt.hour.to_numpy() / 24
    frame["sin_hour"], frame["cos_hour"] = np.sin(angle), np.cos(angle)
    return frame


def load_and_merge():
    hourly = pd.read_csv(DATA / "plant1_hourly.csv", parse_dates=["datetime"])
    weather = pd.read_csv(DATA / "plant1_openmeteo.csv", parse_dates=["datetime"])
    for name, frame in [("plant hourly", hourly), ("public weather", weather)]:
        if frame["datetime"].duplicated().any():
            raise ValueError(f"duplicate timestamps in {name}")
    merged = hourly.merge(weather, how="inner", on="datetime", validate="one_to_one")
    merged = add_hour_features(merged.sort_values("datetime").reset_index(drop=True))
    required = list(dict.fromkeys(["ac_power"] + FEATURES_A + FEATURES_B))
    complete = np.isfinite(merged[required].to_numpy(dtype=float)).all(axis=1)
    dropped = merged.loc[~complete, ["datetime"]].copy()
    dropped["reason"] = "missing/non-finite target or feature; no interpolation"
    dropped.to_csv(RESULTS / "modelling_excluded_hours.csv", index=False)
    facts = {"hourly_rows": len(hourly), "weather_rows": len(weather),
             "merged_rows_before_complete_case": len(merged), "excluded_hours": int((~complete).sum()),
             "complete_case_rows": int(complete.sum()),
             "hourly_without_weather": int((~hourly.datetime.isin(weather.datetime)).sum()),
             "weather_without_hourly": int((~weather.datetime.isin(hourly.datetime)).sum())}
    return merged.loc[complete].reset_index(drop=True), facts


def split_by_date(frame):
    date = frame["datetime"].dt.normalize()
    train = frame.loc[date.between(TRAIN_START, TRAIN_END)].reset_index(drop=True)
    test = frame.loc[date.between(TEST_START, TEST_END)].reset_index(drop=True)
    if train.empty or test.empty or train.datetime.max() >= test.datetime.min():
        raise ValueError("invalid chronological train/test split")
    return train, test


def standardize(train, test, features):
    """Population mean/std from TRAINING ONLY; intercept added after scaling."""
    raw_train, raw_test = train[features].to_numpy(float), test[features].to_numpy(float)
    if not np.isfinite(raw_train).all() or not np.isfinite(raw_test).all():
        raise ValueError("standardization requires complete finite feature rows")
    means, stds = raw_train.mean(axis=0), raw_train.std(axis=0, ddof=0)
    if (stds <= 0).any():
        raise ValueError("cannot standardize a constant training feature")
    X_train = np.column_stack([np.ones(len(train)), (raw_train - means) / stds])
    X_test = np.column_stack([np.ones(len(test)), (raw_test - means) / stds])
    return X_train, X_test, means, stds


def rate_experiment(X, y):
    initial = cost(X, y, np.zeros(X.shape[1]))
    rows, choices = [], {}
    for solver, rates, budget, function in [
        ("batch_gd", [1e-5, 1e-4, 1e-3], 500, fit_batch_gd),
        ("sgd", [1e-4, 1e-3, 1e-2], 50, fit_sgd),
    ]:
        runs = {}
        for alpha in rates:
            try:
                _, values = function(X, y, alpha, budget)
                history = np.asarray(values)
                # Finite but rapidly growing costs are also divergence.
                stable = bool(history[-1] < initial and np.isfinite(history).all())
            except FloatingPointError:
                history, stable = np.full(budget, np.nan), False
            runs[alpha] = (history, stable)
        stable_rates = [a for a, (_, stable) in runs.items() if stable]
        if not stable_rates:
            raise RuntimeError(f"no stable learning rate for {solver}")
        selected = min(stable_rates, key=lambda a: runs[a][0][-1])
        choices[solver] = selected
        fig, ax = plt.subplots(figsize=(8.8, 4.7))
        curve_frame = {"step": np.arange(1, budget + 1)}
        for alpha, (history, stable) in runs.items():
            final = float(history[-1]) if np.isfinite(history[-1]) else None
            label = ("diverged" if not stable else "selected: lowest final training cost"
                     if alpha == selected else "stable, slower at this budget")
            rows.append({"solver": solver, "alpha": alpha, "budget": budget,
                         "initial_cost": initial, "final_cost": final,
                         "stable": stable, "selected": alpha == selected, "assessment": label})
            curve_frame[f"alpha_{alpha:g}"] = history
            ax.plot(np.arange(1, budget + 1), history, label=f"alpha {alpha:g} - {label}")
        ax.set(yscale="log", xlabel="Iteration" if solver == "batch_gd" else "Epoch",
               ylabel="Half-sum squared training error (kW²)",
               title=f"{'Batch GD' if solver == 'batch_gd' else 'Ordered SGD'} | Set A training only")
        ax.grid(alpha=.2)
        ax.legend(fontsize=8)
        fig.tight_layout()
        stem = "batch" if solver == "batch_gd" else "sgd"
        fig.savefig(RESULTS / f"{stem}_learning_rates.png", dpi=170)
        plt.close(fig)
        pd.DataFrame(curve_frame).to_csv(RESULTS / f"{stem}_learning_rate_history.csv", index=False)
    pd.DataFrame(rows).to_csv(RESULTS / "learning_rate_experiments.csv", index=False)
    return choices


def batch_to_normal(X, y, reference, alpha, max_iters=200_000):
    """Require max error <=1e-5 AND actual two-decimal equality for each set.

    A max difference <0.005 alone does not guarantee equal displayed rounding.
    The reference coefficients and stopping criterion use training data only.
    """
    theta, history = np.zeros(X.shape[1]), []
    for iteration in range(1, max_iters + 1):
        theta += alpha * (X.T @ (y - X @ theta))
        residual = X @ theta - y
        value = float(0.5 * (residual @ residual))
        if not np.isfinite(value):
            raise FloatingPointError("selected batch rate diverged on this feature set")
        history.append(value)
        difference = float(np.max(np.abs(theta - reference)))
        if difference <= 1e-5 and np.array_equal(np.round(theta, 2), np.round(reference, 2)):
            return theta, history, iteration, difference
    raise RuntimeError("batch GD failed the explicit convergence criterion")


def main():
    RESULTS.mkdir(parents=True, exist_ok=True)
    merged, merge_facts = load_and_merge()
    train, test = split_by_date(merged)
    y_train, y_test = train.ac_power.to_numpy(float), test.ac_power.to_numpy(float)
    daytime = test.irradiation.to_numpy(float) > 0
    if not daytime.any():
        raise ValueError("no daytime test rows")
    matrices = {name: standardize(train, test, features)
                for name, features in [("A", FEATURES_A), ("B", FEATURES_B)]}
    choices = rate_experiment(matrices["A"][0], y_train)
    table_rows, scaler_rows, solver_facts = [], [], {}
    predictions = test[["datetime", "ac_power", "irradiation"]].copy()
    for feature_set, features in [("A", FEATURES_A), ("B", FEATURES_B)]:
        X_train, X_test, means, stds = matrices[feature_set]
        normal = fit_normal(X_train, y_train)
        batch, batch_history, iterations, batch_diff = batch_to_normal(
            X_train, y_train, normal, choices["batch_gd"])
        sgd, sgd_history = fit_sgd(X_train, y_train, choices["sgd"], FINAL_SGD_EPOCHS)
        sgd_diff = float(np.max(np.abs(sgd - normal)))
        rounded = bool(np.array_equal(np.round(normal, 2), np.round(batch, 2)))
        monotone = bool(np.all(np.diff(batch_history) <= np.maximum(1e-5, np.abs(batch_history[:-1]) * 1e-12)))
        if not rounded or not monotone:
            raise AssertionError("batch convergence/monotonicity check failed")
        solver_facts[feature_set] = {
            "batch_iterations": iterations, "batch_max_abs_theta_difference": batch_diff,
            "batch_round2_equal": rounded, "batch_cost_nonincreasing_with_numeric_tolerance": monotone,
            "sgd_epochs": FINAL_SGD_EPOCHS, "sgd_max_abs_theta_difference": sgd_diff,
            "sgd_round2_equal": bool(np.array_equal(np.round(normal, 2), np.round(sgd, 2))),
            "normal_training_cost": cost(X_train, y_train, normal),
            "batch_final_training_cost": batch_history[-1], "sgd_final_training_cost": sgd_history[-1],
            "gram_condition_number": float(np.linalg.cond(X_train.T @ X_train)),
        }
        pd.DataFrame({"iteration": np.arange(1, iterations + 1), "cost": batch_history}).to_csv(
            RESULTS / f"final_batch_history_set_{feature_set.lower()}.csv", index=False)
        pd.DataFrame({"epoch": np.arange(1, FINAL_SGD_EPOCHS + 1), "cost": sgd_history}).to_csv(
            RESULTS / f"final_sgd_history_set_{feature_set.lower()}.csv", index=False)
        coefficients = {"normal": normal, "batch_gd": batch, "sgd": sgd}
        for solver, theta in coefficients.items():
            raw = X_test @ theta
            clipped = np.maximum(raw, 0)
            suffix = f"{feature_set.lower()}_{'batch' if solver == 'batch_gd' else solver}"
            predictions[f"raw_pred_{suffix}"] = raw
            predictions[f"pred_{suffix}"] = clipped
            table_rows.append({
                "model": f"{feature_set} {solver}", "feature_set": feature_set, "solver": solver,
                "alpha": 0.0 if solver == "normal" else choices[solver],
                "iterations": iterations if solver == "batch_gd" else 0,
                "epochs": FINAL_SGD_EPOCHS if solver == "sgd" else 0,
                "rmse_all_hours": rmse(y_test, clipped),
                "rmse_daytime": rmse(y_test[daytime], clipped[daytime]),
                "all_hours_n": len(test), "daytime_n": int(daytime.sum()),
                "negative_predictions_clipped": int((raw < 0).sum()),
            })
        feature_names = ["intercept"] + features
        theta_table = pd.DataFrame({"feature": feature_names, **coefficients})
        theta_table["abs_diff_batch_vs_normal"] = np.abs(batch - normal)
        theta_table["abs_diff_sgd_vs_normal"] = np.abs(sgd - normal)
        theta_table.to_csv(RESULTS / f"table3_set_{feature_set.lower()}.csv", index=False)
        pd.DataFrame([{"model": f"{feature_set} {solver}", **dict(zip(feature_names, theta))}
                      for solver, theta in coefficients.items()]).to_csv(
            RESULTS / f"theta_table_set_{feature_set.lower()}.csv", index=False)
        np.savez(RESULTS / f"set_{feature_set.lower()}_normal_weights.npz", theta=normal,
                 feature_names=np.asarray(features, dtype="U32"), train_means=means, train_stds=stds,
                 train_feature_min=train[features].min().to_numpy(float),
                 train_feature_max=train[features].max().to_numpy(float))
        scaler_rows.extend({"set": feature_set, "feature": name, "train_mean": float(mean), "train_std": float(std)}
                           for name, mean, std in zip(features, means, stds))
    table = pd.DataFrame(table_rows)
    table.to_csv(RESULTS / "rmse_table.csv", index=False)
    table.to_csv(RESULTS / "table2_model_comparison.csv", index=False)
    predictions.to_csv(RESULTS / "test_predictions.csv", index=False)
    pd.DataFrame(scaler_rows).to_csv(RESULTS / "feature_scaler_stats.csv", index=False)
    summary = {
        **merge_facts, "train_rows": len(train), "test_rows": len(test), "test_daytime_rows": int(daytime.sum()),
        "train_start": str(train.datetime.min()), "train_end": str(train.datetime.max()),
        "test_start": str(test.datetime.min()), "test_end": str(test.datetime.max()),
        "train_peak_kw": float(y_train.max()), "selected_batch_alpha": choices["batch_gd"],
        "selected_sgd_alpha": choices["sgd"], "rate_selection": "minimum final Set A training cost among stable runs",
        "scaler_fit": "training only; population std ddof=0; intercept added afterwards",
        "daytime_definition": "on-site irradiation > 0, identical mask for A and B",
        "prediction_rule": "max(0, X @ theta); no daylight override", "solvers": solver_facts,
        "location_status": "unresolved; approximate location/time alignment; see location_check.md",
        "scope": "Historical aggregate Plant 1 scenario estimates, not validated rooftop or future forecasts",
        "training_decisions_used_test_rows": False,
    }
    (RESULTS / "run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(table.to_string(index=False))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
