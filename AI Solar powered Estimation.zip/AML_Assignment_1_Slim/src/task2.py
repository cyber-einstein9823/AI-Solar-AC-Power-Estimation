"""Compatibility entry point; the required Task 2 implementation is in eda.py."""
from eda import main

if __name__ == "__main__":
    main()
