"""Linear regression from first principles: NumPy only.

The objective is HALF THE SUM of squared errors, not the mean. Batch updates
therefore have no 1/m factor. Column targets are flattened to avoid broadcasting.
"""
import numpy as np


def _vector(value, name):
    value = np.asarray(value, dtype=float)
    if value.ndim == 2 and value.shape[1] == 1:
        value = value[:, 0]
    if value.ndim != 1 or not value.size:
        raise ValueError(f"{name} must be a nonempty vector or single column")
    if not np.isfinite(value).all():
        raise ValueError(f"{name} must contain only finite values")
    return value


def _matrix(value):
    value = np.asarray(value, dtype=float)
    if value.ndim != 2 or not all(value.shape):
        raise ValueError("X must be a nonempty two-dimensional matrix")
    if not np.isfinite(value).all():
        raise ValueError("X must contain only finite values")
    return value


def _training_data(X, y):
    X, y = _matrix(X), _vector(y, "y")
    if len(X) != len(y):
        raise ValueError("X and y must have the same number of rows")
    return X, y


def _settings(alpha, steps):
    if not np.isscalar(alpha) or not np.isfinite(alpha) or alpha <= 0:
        raise ValueError("alpha must be finite and positive")
    if isinstance(steps, (bool, np.bool_)) or not isinstance(steps, (int, np.integer)) or steps < 1:
        raise ValueError("iteration/epoch count must be a positive integer")


def hypothesis(X, theta):
    """Return X @ theta as a one-dimensional prediction vector."""
    X, theta = _matrix(X), _vector(theta, "theta")
    if X.shape[1] != len(theta):
        raise ValueError("theta length must match the number of X columns")
    return X @ theta


def cost(X, y, theta):
    """J(theta) = 0.5 * sum((X @ theta - y)**2)."""
    X, y = _training_data(X, y)
    residual = hypothesis(X, theta) - y
    return float(0.5 * (residual @ residual))


def fit_normal(X, y):
    """Assignment formula: inverse(X.T @ X) @ X.T @ y.

    Explicit inverse matches the exercise; production work would prefer QR/SVD
    or a linear solve. Singular input fails clearly instead of hiding the issue.
    """
    X, y = _training_data(X, y)
    if np.linalg.matrix_rank(X) < X.shape[1]:
        raise ValueError("normal equation needs a full-column-rank design matrix")
    theta = np.linalg.inv(X.T @ X) @ X.T @ y
    if not np.isfinite(theta).all():
        raise FloatingPointError("normal equation produced non-finite coefficients")
    return theta


def fit_batch_gd(X, y, alpha, n_iters):
    """Zero start; theta += alpha * X.T @ (y - X @ theta).

    Return (theta, costs); full half-sum cost is recorded AFTER each update.
    """
    X, y = _training_data(X, y)
    _settings(alpha, n_iters)
    theta, history = np.zeros(X.shape[1]), []
    with np.errstate(over="ignore", invalid="ignore"):
        for _ in range(n_iters):
            theta += alpha * (X.T @ (y - X @ theta))
            residual = X @ theta - y
            value = float(0.5 * (residual @ residual))
            if not np.isfinite(value):
                raise FloatingPointError("batch GD diverged; reduce alpha")
            history.append(value)
    return theta, history


def fit_sgd(X, y, alpha, n_epochs):
    """Ordered, unshuffled row updates; full half-sum cost after each epoch."""
    X, y = _training_data(X, y)
    _settings(alpha, n_epochs)
    theta, history = np.zeros(X.shape[1]), []
    with np.errstate(over="ignore", invalid="ignore"):
        for _ in range(n_epochs):
            for x_i, y_i in zip(X, y):
                theta += alpha * (y_i - theta @ x_i) * x_i
            residual = X @ theta - y
            value = float(0.5 * (residual @ residual))
            if not np.isfinite(value):
                raise FloatingPointError("SGD diverged; reduce alpha")
            history.append(value)
    return theta, history


def rmse(y_true, y_pred):
    """sqrt(mean((actual - predicted)**2)), without a metrics library."""
    actual, predicted = _vector(y_true, "y_true"), _vector(y_pred, "y_pred")
    if actual.shape != predicted.shape:
        raise ValueError("actual and predicted vectors must have matching shapes")
    return float(np.sqrt(np.mean((actual - predicted) ** 2)))


def self_test():
    rng = np.random.default_rng(42)
    X = np.column_stack([np.ones(200), rng.normal(size=(200, 2))])
    y = X @ np.array([3.0, -1.5, 2.0])
    normal = fit_normal(X, y)
    batch, history = fit_batch_gd(X, y, alpha=1e-3, n_iters=500)
    assert np.allclose(normal, [3, -1.5, 2], atol=1e-10)
    assert np.allclose(normal, batch, atol=1e-8)
    assert np.all(np.diff(history) <= 1e-10)
    assert cost(X, y[:, None], normal) < 1e-20
    print("Synthetic self-test passed: parameters, cost descent, target shapes.")


if __name__ == "__main__":
    self_test()
